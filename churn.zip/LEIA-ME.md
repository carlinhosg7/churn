# Máquina de Churn — Kidy

## Instalação (uma vez)
    pip install -r requirements.txt

## Uso
1. Coloque as bases na pasta `dados/` (DADOS_PREDITIVA_*.parquet, DADOS_PRDITIVA_LIMITE.xlsx, base_clientes.xlsx, novos_01.csv).
2. `python motor_churn.py`  → consolida tudo, treina o modelo e grava em `saida/` (~40 s).
   Rode de novo sempre que atualizar as bases (ou dê dois cliques em `atualizar_bases.bat`).
3. `streamlit run app_churn.py`  → abre o dashboard no navegador (ou `rodar_dashboard.bat`).

## Arquivos
- `churn_core.py`   regras de cor, cálculo de ciclo/tendência, sinal de churn (edite aqui para mudar limiares)
- `motor_churn.py`  ETL + modelo preditivo (gradient boosting) + validação temporal
- `app_churn.py`    dashboard (filtros de período, supervisor, representante, UF, cor, sinal; export Excel tarjado)

## Regras
- Amarelo: compra desde o 1º dia de 5 meses antes do mês de referência (out/2026 → desde 01/05/2026)
- Roxo: entre o 1º dia de 11 meses antes e o corte amarelo (01/11/2025 a 30/04/2026)
- Vermelho: sem compra desde 31/10/2025
- A data de referência é a data final do filtro de período: muda a data e a régua anda junto (cenários).
