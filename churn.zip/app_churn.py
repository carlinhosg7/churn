"""
app_churn.py — Dashboard de Churn (Streamlit)

Rodar:   streamlit run app_churn.py
Antes:   python motor_churn.py   (gera a pasta ./saida)
"""
from __future__ import annotations

import io
import json
import os
from datetime import date

import joblib
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from churn_core import (FEATURES, HORIZONTE_DIAS, SINAL_COR, SINAL_ORDEM, STATUS_COR,
                        STATUS_COR_FUNDO, STATUS_DESC, STATUS_ORDEM, calcular_features,
                        classificar_status, cortes_status, motivo_alerta, sinal_churn)

AQUI = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(AQUI, "saida")
SUP_CONSUMIDOR_FINAL = 9900

st.set_page_config(page_title="Churn de Clientes", page_icon="📉", layout="wide")
st.markdown("""
<style>
.block-container{padding-top:1.4rem}
div[data-testid="stMetricValue"]{font-size:1.6rem}
.kpi{border-radius:10px;padding:12px 14px;border:1px solid rgba(128,128,128,.25)}
.kpi .t{font-size:.8rem;opacity:.75}
.kpi .v{font-size:1.55rem;font-weight:700;line-height:1.2}
.kpi .s{font-size:.8rem;opacity:.8}
.tarja{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:6px;vertical-align:middle}
</style>""", unsafe_allow_html=True)


def brl(x, dec=0):
    if pd.isna(x):
        return "-"
    s = f"{x:,.{dec}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {s}"


def num(x):
    return f"{int(x):,}".replace(",", ".")


# ============================================================================ dados
@st.cache_resource(show_spinner="Carregando bases…")
def carregar():
    if not os.path.exists(os.path.join(SAIDA, "pedidos.parquet")):
        st.error("Pasta ./saida não encontrada. Rode antes:  python motor_churn.py")
        st.stop()
    ped = pd.read_parquet(os.path.join(SAIDA, "pedidos.parquet"))
    mix = pd.read_parquet(os.path.join(SAIDA, "mix_linhas.parquet"))
    cli = pd.read_parquet(os.path.join(SAIDA, "dim_clientes.parquet")).set_index("cod_cliente")
    rep = pd.read_parquet(os.path.join(SAIDA, "dim_representantes.parquet")).set_index("cod_rep")["nome_rep"]
    sup = pd.read_parquet(os.path.join(SAIDA, "dim_supervisores.parquet")).set_index("cod_sup")["nome_sup"]
    novos_sem = pd.read_parquet(os.path.join(SAIDA, "novos_sem_venda.parquet"))
    mdl = joblib.load(os.path.join(SAIDA, "modelo_churn.joblib"))
    with open(os.path.join(SAIDA, "metricas_modelo.json"), encoding="utf-8") as f:
        metr = json.load(f)
    ped = ped.merge(cli[["uf"]], left_on="cod_cliente", right_index=True, how="left")
    return ped, mix, cli, rep, sup, novos_sem, mdl, metr


ped_all, mix_all, CLI, REP, SUP, NOVOS_SEM, MODELO, METR = carregar()
DATA_MIN = ped_all["data"].min().date()
DATA_MAX_BASE = ped_all["data"].max().date()
HOJE = date.today()


def nome_rep(c):
    return f"{c} - {REP.get(c, '(sem nome)')}"


# ============================================================================ filtros
st.sidebar.title("📉 Churn de Clientes")
st.sidebar.caption(f"Base: {DATA_MIN:%d/%m/%Y} a {DATA_MAX_BASE:%d/%m/%Y}")

periodo = st.sidebar.date_input("Período de análise (compras consideradas)",
                                value=(DATA_MIN, max(HOJE, DATA_MAX_BASE)),
                                min_value=DATA_MIN, max_value=max(HOJE, DATA_MAX_BASE), format="DD/MM/YYYY")
if not isinstance(periodo, (tuple, list)) or len(periodo) != 2:
    st.info("Selecione a data inicial e a final.")
    st.stop()
dt_ini, dt_fim = pd.Timestamp(periodo[0]), pd.Timestamp(periodo[1])
st.sidebar.caption("A **data final** é a data de referência do churn: simule cenários passados mudando-a.")

with st.sidebar.expander("Regra das cores", expanded=False):
    m_am = st.number_input("Amarelo: compras desde o início de N meses atrás", 1, 24, 5)
    m_rx = st.number_input("Roxo: compras desde o início de N meses atrás", 2, 36, 11)
ini_am, ini_rx = cortes_status(dt_fim, int(m_am), int(m_rx))
st.sidebar.markdown(
    f"<span class='tarja' style='background:{STATUS_COR['AMARELO']}'></span>**Amarelo**: compra desde {ini_am:%d/%m/%Y}<br>"
    f"<span class='tarja' style='background:{STATUS_COR['ROXO']}'></span>**Roxo**: {ini_rx:%d/%m/%Y} a {(ini_am - pd.Timedelta(days=1)):%d/%m/%Y}<br>"
    f"<span class='tarja' style='background:{STATUS_COR['VERMELHO']}'></span>**Vermelho**: sem compra desde {(ini_rx - pd.Timedelta(days=1)):%d/%m/%Y}",
    unsafe_allow_html=True)

st.sidebar.divider()
excluir_cf = st.sidebar.checkbox("Excluir consumidor final (sup. 9900 / rep. 999)", value=True,
                                 help="~17 mil pessoas físicas que compraram em 2023-2024 por um canal encerrado. "
                                      "Incluí-los infla o churn.")
base = ped_all[ped_all["cod_sup"] != SUP_CONSUMIDOR_FINAL] if excluir_cf else ped_all

sups_disp = sorted(base["cod_sup"].unique())
sel_sup = st.sidebar.multiselect("Supervisor", sups_disp, format_func=lambda c: SUP.get(c, str(c)))
if sel_sup:
    base = base[base["cod_sup"].isin(sel_sup)]
reps_disp = sorted(base["cod_rep"].unique())
sel_rep = st.sidebar.multiselect("Representante", reps_disp, format_func=nome_rep)
if sel_rep:
    base = base[base["cod_rep"].isin(sel_rep)]
ufs = sorted(base["uf"].dropna().unique())
sel_uf = st.sidebar.multiselect("UF", ufs)
if sel_uf:
    base = base[base["uf"].isin(sel_uf)]
so_novos = st.sidebar.checkbox("Somente clientes novos (lista novos_01)")
if so_novos:
    base = base[base["cod_cliente"].isin(CLI.index[CLI["cliente_novo"] == "SIM"])]


# ============================================================================ cálculo
@st.cache_data(show_spinner="Calculando churn…", max_entries=30)
def calcular(chave, _ped, dt_ini, dt_fim, m_am, m_rx):
    p = _ped[(_ped["data"] >= dt_ini) & (_ped["data"] <= dt_fim)]
    if p.empty:
        return None
    ref = dt_fim
    f = calcular_features(p, ref)
    ini_am, ini_rx = cortes_status(ref, m_am, m_rx)
    f["status"] = classificar_status(f["ultima_compra"], ini_am, ini_rx)

    ativos = f["recencia_dias"] < 365
    f["prob_churn"] = np.nan
    if ativos.any():
        f.loc[ativos, "prob_churn"] = MODELO.predict_proba(f.loc[ativos, FEATURES])[:, 1]

    # rep / supervisor principal = maior faturamento nos últimos 24 meses do cliente (no filtro)
    # (janela de 24 meses contada a partir da última compra do cliente, para os vermelhos também terem rep)
    ult_cli = p["cod_cliente"].map(f["ultima_compra"])
    p24 = p[p["data"] > ult_cli - pd.Timedelta(days=730)]
    pr =(p24.groupby(["cod_cliente", "cod_rep", "cod_sup"])["valor"].sum().reset_index()
             .sort_values("valor", ascending=False).drop_duplicates("cod_cliente").set_index("cod_cliente"))
    f["cod_rep"] = pr["cod_rep"].reindex(f.index)
    f["cod_sup"] = pr["cod_sup"].reindex(f.index)
    f["valor_periodo"] = p.groupby("cod_cliente")["valor"].sum()
    f["pedidos_periodo"] = p.groupby("cod_cliente")["pedido"].nunique()

    f = f.join(CLI[["razao_social", "grupo", "cidade", "uf", "limite_disponivel", "bloqueado", "cliente_novo"]])
    f["sinal"] = sinal_churn(f)
    f["motivo"] = [motivo_alerta(r) if s in ("Atenção", "Entrando em churn") else ""
                   for s, r in zip(f["sinal"], f.to_dict("records"))]
    f["representante"] = [nome_rep(int(c)) if pd.notna(c) else "" for c in f["cod_rep"]]
    f["supervisor"] = [SUP.get(int(c), str(c)) if pd.notna(c) else "" for c in f["cod_sup"]]
    return f.reset_index()


@st.cache_data(show_spinner="Montando evolução mensal…", max_entries=30)
def evolucao(chave, _ped, dt_ini, dt_fim, m_am, m_rx):
    """Para cada fim de mês: quantos clientes estavam em cada cor (mesma regra, data móvel)."""
    p = _ped[(_ped["data"] >= dt_ini) & (_ped["data"] <= dt_fim)]
    if p.empty:
        return None
    mi = (p["data"].dt.year * 12 + p["data"].dt.month - 1).to_numpy()
    m0, m1 = int(mi.min()), int(dt_fim.year * 12 + dt_fim.month - 1)
    cli_codes, ci = np.unique(p["cod_cliente"].to_numpy(), return_inverse=True)
    n_m = m1 - m0 + 1
    M = np.zeros((len(cli_codes), n_m), dtype=bool)
    M[ci, mi - m0] = True
    idx = np.where(M, np.arange(n_m)[None, :], -1)
    ultima = np.maximum.accumulate(idx, axis=1)            # último mês com compra até cada mês
    rows = []
    for j in range(n_m):
        u = ultima[:, j]
        tem = u >= 0
        rec = j - u[tem]
        am = int((rec <= m_am).sum())                     # comprou do mês (ref-5) até o mês ref
        rx = int(((rec > m_am) & (rec <= m_rx)).sum())
        vm = int((rec > m_rx).sum())
        novos_vm = int((rec == m_rx + 1).sum())             # viraram vermelho neste mês
        if j > 0:
            prev = ultima[:, j - 1]
            reat = int((M[:, j] & (prev >= 0) & (j - prev > m_rx)).sum())
        else:
            reat = 0
        y, mth = divmod(m0 + j, 12)
        rows.append({"mes": pd.Timestamp(year=y, month=mth + 1, day=1), "AMARELO": am, "ROXO": rx,
                     "VERMELHO": vm, "entraram_churn": novos_vm, "reativados": reat,
                     "compraram_no_mes": int(M[:, j].sum())})
    ev = pd.DataFrame(rows)
    fat = p.groupby(p["data"].dt.to_period("M").dt.to_timestamp())["valor"].sum()
    ev["faturamento"] = ev["mes"].map(fat).fillna(0)
    return ev


chave = (tuple(sel_sup), tuple(sel_rep), tuple(sel_uf), so_novos, excluir_cf)
df = calcular(chave, base, dt_ini, dt_fim, int(m_am), int(m_rx))
if df is None or df.empty:
    st.warning("Nenhuma compra no período/filtros selecionados.")
    st.stop()

sel_status = st.sidebar.multiselect("Cor (status)", STATUS_ORDEM, default=STATUS_ORDEM)
sel_sinal = st.sidebar.multiselect("Sinal de churn", SINAL_ORDEM, default=SINAL_ORDEM)
dfv = df[df["status"].isin(sel_status) & df["sinal"].isin(sel_sinal)]


# ============================================================================ cabeçalho
st.title("Análise de Churn de Clientes")
filtros_txt = []
if sel_sup:
    filtros_txt.append("Sup.: " + ", ".join(SUP.get(c, str(c)) for c in sel_sup))
if sel_rep:
    filtros_txt.append(f"{len(sel_rep)} representante(s)")
if sel_uf:
    filtros_txt.append("UF: " + ", ".join(sel_uf))
st.caption(f"Período {dt_ini:%d/%m/%Y} a {dt_fim:%d/%m/%Y} · referência {dt_fim:%d/%m/%Y} · "
           + (" · ".join(filtros_txt) if filtros_txt else "todos os supervisores e representantes"))

tot = len(dfv)
cont = dfv["status"].value_counts().reindex(STATUS_ORDEM, fill_value=0)
entrando = dfv[dfv["sinal"] == "Entrando em churn"]
atencao = dfv[dfv["sinal"] == "Atenção"]

c = st.columns(6)


def kpi(col, titulo, valor, sub="", cor=None):
    borda = f"border-left:6px solid {cor};" if cor else ""
    col.markdown(f"<div class='kpi' style='{borda}'><div class='t'>{titulo}</div>"
                 f"<div class='v'>{valor}</div><div class='s'>{sub}</div></div>", unsafe_allow_html=True)


kpi(c[0], "Clientes na carteira", num(tot), f"Faturamento no período: {brl(dfv['valor_periodo'].sum())}")
for i, s in enumerate(STATUS_ORDEM, start=1):
    kpi(c[i], f"{s.title()} · {STATUS_DESC[s]}", num(cont[s]), f"{cont[s] / max(tot, 1):.1%} da carteira", STATUS_COR[s])
kpi(c[4], "⚠️ Entrando em churn", num(len(entrando)),
    f"Faturou {brl(entrando['valor_365'].sum())} nos últimos 12m", SINAL_COR["Entrando em churn"])
kpi(c[5], "Atenção", num(len(atencao)), f"Faturou {brl(atencao['valor_365'].sum())} nos últimos 12m", SINAL_COR["Atenção"])
st.write("")

aba = st.tabs(["📊 Visão geral", "🚨 Sinal de churn", "👥 Supervisor / Representante",
               "📋 Clientes", "🔎 Cliente (detalhe)", "🆕 Clientes novos", "ℹ️ Como funciona"])

LAYOUT = dict(margin=dict(l=10, r=10, t=40, b=10), legend=dict(orientation="h", y=-0.15),
              hoverlabel=dict(bgcolor="white"), font=dict(size=12))

# ---------------------------------------------------------------------------- visão geral
with aba[0]:
    ev = evolucao(chave, base, dt_ini, dt_fim, int(m_am), int(m_rx))
    col1, col2 = st.columns([1, 2])
    with col1:
        fig = go.Figure(go.Bar(x=STATUS_ORDEM, y=cont.values, marker_color=[STATUS_COR[s] for s in STATUS_ORDEM],
                               text=[f"{v:,}".replace(",", ".") + f"<br>{v / max(tot, 1):.0%}" for v in cont.values],
                               textposition="outside", hovertemplate="%{x}: %{y:,} clientes<extra></extra>"))
        fig.update_layout(title="Clientes por cor (na referência)", yaxis_title="clientes", **LAYOUT)
        st.plotly_chart(fig, width="stretch")
    with col2:
        if ev is not None:
            ev_ = ev[ev["mes"] >= dt_ini.replace(day=1)]
            fig = go.Figure()
            for s in STATUS_ORDEM:
                fig.add_bar(x=ev_["mes"], y=ev_[s], name=s.title(), marker_color=STATUS_COR[s],
                            hovertemplate=f"{s.title()}: " + "%{y:,}<extra></extra>")
            fig.update_layout(barmode="stack", bargap=0.08, title="Evolução da carteira por cor (fim de cada mês, regra móvel)",
                              yaxis_title="clientes", hovermode="x unified", **LAYOUT)
            st.plotly_chart(fig, width="stretch")
    if ev is not None:
        col3, col4 = st.columns(2)
        ev_ = ev[ev["mes"] >= dt_ini.replace(day=1)]
        with col3:
            fig = go.Figure()
            fig.add_scatter(x=ev_["mes"], y=ev_["entraram_churn"], name="Viraram vermelho no mês",
                            line=dict(color=STATUS_COR["VERMELHO"], width=2))
            fig.add_scatter(x=ev_["mes"], y=ev_["reativados"], name="Reativados (eram vermelho e compraram)",
                            line=dict(color="#2E9E5B", width=2))
            fig.update_layout(title="Entradas em churn x reativações por mês", yaxis_title="clientes",
                              hovermode="x unified", **LAYOUT)
            st.plotly_chart(fig, width="stretch")
        with col4:
            fig = go.Figure(go.Bar(x=ev_["mes"], y=ev_["faturamento"], marker_color="#4C78A8",
                                   hovertemplate="%{x|%b/%Y}: R$ %{y:,.0f}<extra></extra>"))
            fig.update_layout(title="Faturamento mensal", yaxis_title="R$", **LAYOUT)
            st.plotly_chart(fig, width="stretch")
        st.caption("Obs.: 2020 a 2022 têm pouquíssimos registros na base enviada; leituras desse período não são confiáveis.")

# ---------------------------------------------------------------------------- sinal de churn
with aba[1]:
    st.subheader("Quem está entrando em churn")
    st.markdown(
        "O **sinal** combina três leituras: o **atraso em relação ao ciclo de compra do próprio cliente**, "
        f"a **queda de faturamento** (12 meses x 12 anteriores) e a **probabilidade do modelo** de o cliente "
        f"não comprar nos próximos {HORIZONTE_DIAS} dias.")
    col1, col2 = st.columns([1, 1])
    with col1:
        ct = pd.crosstab(dfv["status"], dfv["sinal"]).reindex(index=STATUS_ORDEM, columns=SINAL_ORDEM, fill_value=0)
        fig = go.Figure()
        for s in SINAL_ORDEM:
            fig.add_bar(y=[x.title() for x in ct.index], x=ct[s], name=s, orientation="h", marker_color=SINAL_COR[s],
                        hovertemplate=f"{s}: " + "%{x:,}<extra></extra>")
        fig.update_layout(barmode="stack", title="Sinal de churn dentro de cada cor", xaxis_title="clientes", **LAYOUT)
        st.plotly_chart(fig, width="stretch")
    with col2:
        risco = dfv[dfv["sinal"].isin(["Entrando em churn", "Atenção"])]
        g = risco.groupby("sinal")["valor_365"].sum().reindex(["Entrando em churn", "Atenção"], fill_value=0)
        fig = go.Figure(go.Bar(x=g.index, y=g.values, marker_color=[SINAL_COR[s] for s in g.index],
                               text=[brl(v) for v in g.values], textposition="outside",
                               hovertemplate="%{x}: R$ %{y:,.0f}<extra></extra>"))
        fig.update_layout(title="Faturamento 12m dos clientes em risco", yaxis_title="R$", **LAYOUT)
        st.plotly_chart(fig, width="stretch")

    so = st.radio("Mostrar", ["Entrando em churn", "Atenção", "Ambos"], horizontal=True)
    lista = dfv[dfv["sinal"].isin(["Entrando em churn", "Atenção"] if so == "Ambos" else [so])].copy()
    lista = lista.sort_values("valor_365", ascending=False)
    cols = ["cod_cliente", "razao_social", "status", "sinal", "prob_churn", "ultima_compra", "recencia_dias",
            "ciclo_mediano", "atraso_ciclo", "valor_365", "valor_365_ant", "motivo", "representante",
            "supervisor", "uf", "bloqueado", "limite_disponivel"]
    st.dataframe(
        lista[cols], hide_index=True, width="stretch", height=480,
        column_config={
            "cod_cliente": "Código", "razao_social": "Cliente", "status": "Cor", "sinal": "Sinal",
            "prob_churn": st.column_config.ProgressColumn("Prob. churn", format="percent", min_value=0, max_value=1),
            "ultima_compra": st.column_config.DateColumn("Última compra", format="DD/MM/YYYY"),
            "recencia_dias": "Dias sem comprar", "ciclo_mediano": st.column_config.NumberColumn("Ciclo (dias)", format="%.0f"),
            "atraso_ciclo": st.column_config.NumberColumn("Atraso x ciclo", format="%.1fx"),
            "valor_365": st.column_config.NumberColumn("Fat. 12m", format="R$ %.0f"),
            "valor_365_ant": st.column_config.NumberColumn("Fat. 12m anterior", format="R$ %.0f"),
            "motivo": "Por quê", "representante": "Representante", "supervisor": "Supervisor", "uf": "UF",
            "bloqueado": "Bloqueado", "limite_disponivel": st.column_config.NumberColumn("Limite disp.", format="R$ %.0f"),
        })
    with st.expander("Qualidade do modelo (teste em períodos que ele não viu)"):
        st.markdown(
            f"- Testado nos cortes {', '.join(METR['cortes_teste'])}: **AUC {METR['auc_teste']:.2f}** "
            f"(0,5 = sorteio; 1,0 = perfeito)\n"
            f"- Dos clientes com probabilidade ≥ 40%, **{METR.get('precisao_teste@0.40', 0):.0%}** de fato ficaram "
            f"{HORIZONTE_DIAS} dias sem comprar (taxa média da base: {METR['taxa_churn_teste']:.0%}).\n"
            + (lambda b: f"- **Backtest do sinal** (foto em {b['referencia']}, conferindo os {HORIZONTE_DIAS} dias seguintes): "
               + " · ".join(f"{k}: **{b['pct_nao_comprou'].get(k, 0):.0%}** não compraram ({b['clientes'].get(k, 0):,} clientes)"
                            for k in ["Entrando em churn", "Atenção", "Saudável"]) + "\n")(METR["backtest_sinal"])
            + "- Para validar um cenário você mesmo: coloque a data final 9 meses atrás, exporte a lista de "
            "'Entrando em churn' e confira quem comprou depois.")

# ---------------------------------------------------------------------------- supervisor / rep
def resumo(dfx, chave_col):
    t = pd.crosstab(dfx[chave_col], dfx["status"]).reindex(columns=STATUS_ORDEM, fill_value=0)
    s = pd.crosstab(dfx[chave_col], dfx["sinal"]).reindex(columns=SINAL_ORDEM, fill_value=0)
    t["Total"] = t.sum(axis=1)
    t["% Amarelo"] = t["AMARELO"] / t["Total"]
    t["% Roxo"] = t["ROXO"] / t["Total"]
    t["% Vermelho"] = t["VERMELHO"] / t["Total"]
    t["Entrando em churn"] = s["Entrando em churn"]
    t["Atenção"] = s["Atenção"]
    t["Fat. 12m em risco"] = dfx[dfx["sinal"].isin(["Entrando em churn", "Atenção"])].groupby(chave_col)["valor_365"].sum()
    t["Fat. período"] = dfx.groupby(chave_col)["valor_periodo"].sum()
    return t.fillna(0).sort_values("Total", ascending=False)


CFG_RESUMO = {
    "% Amarelo": st.column_config.ProgressColumn("% Amarelo", format="percent", min_value=0, max_value=1),
    "% Roxo": st.column_config.ProgressColumn("% Roxo", format="percent", min_value=0, max_value=1),
    "% Vermelho": st.column_config.ProgressColumn("% Vermelho", format="percent", min_value=0, max_value=1),
    "Fat. 12m em risco": st.column_config.NumberColumn(format="R$ %.0f"),
    "Fat. período": st.column_config.NumberColumn(format="R$ %.0f"),
}

with aba[2]:
    rs = resumo(dfv, "supervisor")
    fig = go.Figure()
    for s in STATUS_ORDEM:
        fig.add_bar(y=rs.index, x=rs[s], name=s.title(), orientation="h", marker_color=STATUS_COR[s],
                    hovertemplate="%{y}<br>" + s.title() + ": %{x:,}<extra></extra>")
    fig.update_layout(barmode="stack", title="Carteira por supervisor", height=max(320, 34 * len(rs) + 120),
                      yaxis=dict(autorange="reversed"), xaxis_title="clientes", **LAYOUT)
    st.plotly_chart(fig, width="stretch")
    st.markdown("**Resumo por supervisor**")
    st.dataframe(rs, width="stretch", column_config=CFG_RESUMO)
    st.markdown("**Resumo por representante**")
    rr = resumo(dfv, "representante")
    rr.insert(0, "Supervisor", dfv.groupby("representante")["supervisor"].agg(lambda s: s.mode().iat[0]))
    st.dataframe(rr, width="stretch", column_config=CFG_RESUMO, height=520)

# ---------------------------------------------------------------------------- clientes
def colorir(row):
    return [f"background-color: {STATUS_COR_FUNDO[row['Cor']]}"] * len(row)


COLS_CLI = {"cod_cliente": "Código", "razao_social": "Cliente", "grupo": "Grupo", "status": "Cor",
            "sinal": "Sinal", "prob_churn": "Prob. churn", "ultima_compra": "Última compra",
            "recencia_dias": "Dias sem comprar", "ciclo_mediano": "Ciclo (dias)", "atraso_ciclo": "Atraso x ciclo",
            "valor_365": "Fat. 12m", "valor_365_ant": "Fat. 12m anterior", "valor_periodo": "Fat. período",
            "pedidos_periodo": "Pedidos período", "motivo": "Por quê", "representante": "Representante",
            "supervisor": "Supervisor", "cidade": "Cidade", "uf": "UF", "bloqueado": "Bloqueado",
            "limite_disponivel": "Limite disp.", "cliente_novo": "Cliente novo"}

with aba[3]:
    busca = st.text_input("Buscar cliente (nome ou código)")
    tab = dfv[list(COLS_CLI)].rename(columns=COLS_CLI).sort_values(["Cor", "Fat. 12m"], ascending=[True, False])
    if busca:
        b = busca.strip().upper()
        tab = tab[tab["Cliente"].astype(str).str.upper().str.contains(b, regex=False) | (tab["Código"].astype(str) == b)]
    st.caption(f"{num(len(tab))} clientes · linhas tarjadas pela cor do status (tela mostra até 3.000; o Excel leva todos)")
    vis = tab.head(3000)
    st.dataframe(
        vis.style.apply(colorir, axis=1).format({"Prob. churn": "{:.0%}", "Fat. 12m": "R$ {:,.0f}",
                                                 "Fat. 12m anterior": "R$ {:,.0f}", "Fat. período": "R$ {:,.0f}",
                                                 "Ciclo (dias)": "{:.0f}", "Atraso x ciclo": "{:.1f}x",
                                                 "Limite disp.": "R$ {:,.0f}", "Última compra": "{:%d/%m/%Y}"},
                                                na_rep="-"),
        hide_index=True, width="stretch", height=560)

    def gerar_excel(tab_cli):
        bio = io.BytesIO()
        with pd.ExcelWriter(bio, engine="xlsxwriter", datetime_format="dd/mm/yyyy") as w:
            wb = w.book
            tab_cli.to_excel(w, sheet_name="Clientes", index=False)
            ws = w.sheets["Clientes"]
            n = len(tab_cli)
            col_cor = tab_cli.columns.get_loc("Cor")
            letra = chr(ord("A") + col_cor)
            for s in STATUS_ORDEM:
                ws.conditional_format(1, 0, n, len(tab_cli.columns) - 1, {
                    "type": "formula", "criteria": f'=${letra}2="{s}"',
                    "format": wb.add_format({"bg_color": STATUS_COR_FUNDO[s]})})
            ws.autofilter(0, 0, n, len(tab_cli.columns) - 1)
            ws.freeze_panes(1, 2)
            ws.set_column(0, 0, 9); ws.set_column(1, 2, 36); ws.set_column(3, 30, 15)
            pct = wb.add_format({"num_format": "0%"}); moeda = wb.add_format({"num_format": "R$ #,##0"})
            for nome_c in ["Prob. churn"]:
                i = tab_cli.columns.get_loc(nome_c); ws.set_column(i, i, 11, pct)
            for nome_c in ["Fat. 12m", "Fat. 12m anterior", "Fat. período", "Limite disp."]:
                i = tab_cli.columns.get_loc(nome_c); ws.set_column(i, i, 15, moeda)
            i = tab_cli.columns.get_loc("Por quê"); ws.set_column(i, i, 50)
            al = tab_cli[tab_cli["Sinal"].isin(["Entrando em churn", "Atenção"])].sort_values("Fat. 12m", ascending=False)
            al.to_excel(w, sheet_name="Alertas", index=False)
            w.sheets["Alertas"].set_column(0, 30, 16); w.sheets["Alertas"].set_column(1, 1, 36)
            resumo(dfv, "supervisor").to_excel(w, sheet_name="Resumo Supervisor")
            resumo(dfv, "representante").to_excel(w, sheet_name="Resumo Representante")
            pd.DataFrame({"Parâmetro": ["Período", "Referência", "Amarelo", "Roxo", "Vermelho", "Filtros"],
                          "Valor": [f"{dt_ini:%d/%m/%Y} a {dt_fim:%d/%m/%Y}", f"{dt_fim:%d/%m/%Y}",
                                    f"compra desde {ini_am:%d/%m/%Y}",
                                    f"{ini_rx:%d/%m/%Y} a {ini_am - pd.Timedelta(days=1):%d/%m/%Y}",
                                    f"sem compra desde {ini_rx - pd.Timedelta(days=1):%d/%m/%Y}",
                                    " · ".join(filtros_txt) or "nenhum"]}).to_excel(w, sheet_name="Parâmetros", index=False)
        return bio.getvalue()

    if st.button("Gerar Excel (tarjado por cor)"):
        st.download_button("⬇️ Baixar Excel", gerar_excel(tab),
                           file_name=f"churn_{dt_fim:%Y%m%d}.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# ---------------------------------------------------------------------------- detalhe do cliente
with aba[4]:
    opcoes = dfv.sort_values("valor_365", ascending=False)
    esc = st.selectbox("Cliente", opcoes["cod_cliente"].tolist(),
                       format_func=lambda c: f"{c} - {CLI['razao_social'].get(c, '')}")
    if esc is not None:
        r = df[df["cod_cliente"] == esc].iloc[0]
        c1, c2, c3, c4, c5 = st.columns(5)
        kpi(c1, "Cor", r["status"].title(), STATUS_DESC[r["status"]], STATUS_COR[r["status"]])
        kpi(c2, "Sinal", r["sinal"], r["motivo"] or "-", SINAL_COR[r["sinal"]])
        kpi(c3, "Última compra", f"{r['ultima_compra']:%d/%m/%Y}", f"{int(r['recencia_dias'])} dias")
        kpi(c4, "Ciclo de compra", f"{r['ciclo_mediano']:.0f} dias" if pd.notna(r["ciclo_mediano"]) else "-",
            f"atraso {r['atraso_ciclo']:.1f}x" if pd.notna(r["atraso_ciclo"]) else "")
        kpi(c5, "Prob. churn (modelo)", f"{r['prob_churn']:.0%}" if pd.notna(r["prob_churn"]) else "-",
            f"Fat. 12m {brl(r['valor_365'])}")
        pc = base[(base["cod_cliente"] == esc) & (base["data"] <= dt_fim)]
        mens = pc.groupby(pc["data"].dt.to_period("M").dt.to_timestamp())["valor"].sum()
        fig = go.Figure(go.Bar(x=mens.index, y=mens.values, marker_color="#4C78A8",
                               hovertemplate="%{x|%b/%Y}: R$ %{y:,.0f}<extra></extra>"))
        for s, d0 in (("ROXO", ini_rx), ("AMARELO", ini_am)):
            fig.add_vline(x=d0, line_dash="dot", line_color=STATUS_COR[s])
        fig.update_layout(title="Compras mensais do cliente (linhas pontilhadas = cortes roxo/amarelo)", yaxis_title="R$", **LAYOUT)
        st.plotly_chart(fig, width="stretch")
        mx = mix_all[(mix_all["cod_cliente"] == esc) & (mix_all["mes"] <= dt_fim)]
        if not mx.empty:
            ref = dt_fim
            a = mx[mx["mes"] > ref - pd.DateOffset(months=12)].groupby("linha")["valor"].sum().rename("Últimos 12m")
            b = mx[(mx["mes"] <= ref - pd.DateOffset(months=12)) & (mx["mes"] > ref - pd.DateOffset(months=24))] \
                .groupby("linha")["valor"].sum().rename("12m anteriores")
            t = pd.concat([a, b], axis=1).fillna(0)
            t["Variação"] = t["Últimos 12m"] - t["12m anteriores"]
            st.markdown("**Mix de linhas: o que o cliente parou de comprar**")
            st.dataframe(t.sort_values("Variação"), width="stretch",
                         column_config={k: st.column_config.NumberColumn(format="R$ %.0f") for k in t.columns})

# ---------------------------------------------------------------------------- novos
with aba[5]:
    nv = df[df["cliente_novo"] == "SIM"]
    st.markdown(f"**{num(len(nv))}** clientes da lista de novos têm compra na base filtrada. "
                f"**{num(len(NOVOS_SEM))}** clientes novos ainda não aparecem nas vendas (lista abaixo).")
    if len(nv):
        cc = nv["status"].value_counts().reindex(STATUS_ORDEM, fill_value=0)
        st.markdown(" · ".join(f"<span class='tarja' style='background:{STATUS_COR[s]}'></span>{s.title()}: {cc[s]}"
                               for s in STATUS_ORDEM), unsafe_allow_html=True)
        st.dataframe(nv[["cod_cliente", "razao_social", "status", "sinal", "primeira_compra", "ultima_compra",
                         "pedidos_periodo", "valor_periodo", "representante", "supervisor", "uf"]]
                     .sort_values("valor_periodo", ascending=False),
                     hide_index=True, width="stretch",
                     column_config={"primeira_compra": st.column_config.DateColumn("1ª compra", format="DD/MM/YYYY"),
                                    "ultima_compra": st.column_config.DateColumn("Última compra", format="DD/MM/YYYY"),
                                    "valor_periodo": st.column_config.NumberColumn("Fat. período", format="R$ %.0f")})
    with st.expander("Novos sem venda na base"):
        st.dataframe(NOVOS_SEM, hide_index=True, width="stretch")

# ---------------------------------------------------------------------------- como funciona
with aba[6]:
    st.markdown(f"""
### Cores (regra móvel pela data de referência = data final do filtro)
| Cor | Regra | Com referência em {dt_fim:%d/%m/%Y} |
|---|---|---|
| 🟨 Amarelo | última compra desde o 1º dia de {int(m_am)} meses antes do mês de referência | compra desde {ini_am:%d/%m/%Y} |
| 🟪 Roxo | última compra entre o 1º dia de {int(m_rx)} meses antes e o corte amarelo | {ini_rx:%d/%m/%Y} a {ini_am - pd.Timedelta(days=1):%d/%m/%Y} |
| 🟥 Vermelho | sem compra desde então | até {ini_rx - pd.Timedelta(days=1):%d/%m/%Y} |

Com a referência em outubro/2026 a regra é exatamente a pedida: amarelo desde 01/05/2026, roxo de 01/11/2025 a 30/04/2026, vermelho até 31/10/2025.
Mudando a data final, a mesma régua é aplicada ao passado (ex.: referência 31/12/2024 → amarelo desde 01/07/2024).

### Sinal de churn
- **Churn**: já está vermelho.
- **Entrando em churn**: probabilidade do modelo ≥ 55%, **ou** está há mais de 2x o seu ciclo normal (e 90+ dias) sem comprar, **ou** está roxo e o faturamento de 12 meses caiu mais de 40%.
- **Atenção**: probabilidade ≥ 40%, **ou** atraso ≥ 1,5x o ciclo (e 60+ dias), **ou** queda de faturamento > 40%.
- **Saudável**: nenhum dos sinais.

**Ciclo de compra** = mediana dos dias entre as \"ondas\" de compra do cliente nos últimos 3 anos (pedidos a menos de 15 dias um do outro contam como a mesma onda; ciclo mínimo de 30 dias). Um cliente que compra a cada 60 dias e está há 130 sem comprar já acende alerta, mesmo ainda amarelo.

**Modelo preditivo**: gradient boosting treinado em {len(METR['cortes_treino'])} fotografias trimestrais da carteira (2018-2019 e 2024-2025),
prevendo se o cliente ativo **não vai comprar nos próximos {HORIZONTE_DIAS} dias**. Usa recência, frequência, faturamento e tendência,
ticket, meses ativos, ciclo, tempo de casa, prazo médio, % pronta entrega, nº de representantes. AUC no teste: {METR['auc_teste']:.2f}.

### Observações da base
- Supervisor **9900 / rep. 999** = ~17 mil pessoas físicas (2023-2024), canal que parou; por padrão fica fora.
- Supervisores **9900 e 9901** não têm nome nas planilhas de cadastro/limite.
- **2020 a 2022** têm pouquíssimos registros na base enviada; trate esse período com cautela.
- Rep./supervisor do cliente = o de maior faturamento com ele nos últimos 24 meses (dentro do filtro).
""")
