"""Visão principal de retenção por coleção."""
import io
import pandas as pd
import streamlit as st
import plotly.express as px
from churn_colecoes import calcular_colecoes


def mostrar(pedidos, clientes, referencia, reps, sups):
    st.header('🎯 Retenção de clientes por coleção')
    dados, m = calcular_colecoes(pedidos, clientes, referencia)
    st.caption(f"Coleção encerrada: **{m['colecao']}** • fechamento em {m['fim']:%d/%m/%Y} • grupos únicos pelo campo Grupo Cliente; registros sem grupo são excluídos")
    if dados.empty:
        st.info(f"Sem histórico para o período selecionado. Grupos distintos cadastrados: {m.get('grupos_cadastro',0):,}.".replace(',', '.'))
        return
    a,b,c,d = st.columns(4)
    a.metric('Grupos com compra desde 01/01/2024',f"{m['grupos_cadastro']:,}".replace(',','.'))
    b.metric('🔴 Churn confirmado',f"{m['pct_churn']:.1%}",f"{m['churn']:,} grupos".replace(',','.'))
    c.metric('🟠 Possível churn',f"{m['pct_risco']:.1%}",f"{m['risco']:,} grupos".replace(',','.'))
    d.metric('🟢 Ativos',f"{m['ativos']:,}".replace(',','.'),f"{m['novos']} novos na última coleção (fora da base)")
    st.caption(f"Auditoria: {m['grupos_cadastro']:,} grupos distintos com compra desde 01/01/2024 • {m.get('grupos_historicos',0):,} grupos no histórico de pedidos • {m.get('grupos_com_historico',0):,} grupos da carteira com compras até o corte • {m['elegiveis']:,} grupos elegíveis ao cálculo das taxas.".replace(',', '.'))
    st.info('**Regra:** churn = 2 coleções completas consecutivas sem compra; possível churn = 1 coleção completa sem compra. A coleção em andamento não gera churn confirmado. A taxa usa apenas grupos já existentes antes da última coleção encerrada.')
    eleg = dados[dados['elegivel']].copy()
    graf = eleg['status'].value_counts().reindex(['Ativo','Possível churn','Churn'],fill_value=0).reset_index()
    graf.columns=['Situação','Grupos']
    col1,col2=st.columns([1,2])
    with col1:
        fig=px.pie(graf,names='Situação',values='Grupos',hole=.6,color='Situação',color_discrete_map={'Ativo':'#33b884','Possível churn':'#f0aa3d','Churn':'#e74c59'})
        fig.update_layout(title='Saúde da carteira',margin=dict(t=45,b=5,l=5,r=5))
        st.plotly_chart(fig,use_container_width=True)
    with col2:
        problem=eleg[eleg['status'].isin(['Churn','Possível churn'])]
        st.subheader('Situação financeira dos grupos em risco/perdidos')
        x,y,z=st.columns(3)
        x.metric('Com algum bloqueio',f"{problem['bloqueio'].isin(['Todas','Parcial']).mean():.1%}" if len(problem) else '0%')
        y.metric('Sem limite positivo',f"{(problem['situacao_limite']=='Sem limite').mean():.1%}" if len(problem) else '0%')
        z.metric('Com limite e sem bloqueio',f"{((problem['situacao_limite']=='Com limite')&(problem['bloqueio']=='Não')).mean():.1%}" if len(problem) else '0%')
        st.caption('Bloqueio parcial: ao menos uma empresa do grupo bloqueada. Limite: soma dos limites informados, não necessariamente crédito disponível consolidado.')
    st.subheader('🔎 Quem são os grupos?')
    a,b=st.columns([1,2])
    with a:
        situacoes=st.multiselect('Situação', ['Churn','Possível churn','Ativo','Novo na última coleção'],default=['Churn','Possível churn'])
    with b:
        busca=st.text_input('Pesquisar Grupo Cliente',placeholder='Digite código ou nome do grupo')
    tabela=dados[dados['status'].isin(situacoes)].copy()
    if busca:
        tabela=tabela[tabela['codigo_grupo'].astype(str).str.contains(busca,case=False,regex=False)|tabela['nome'].astype(str).str.contains(busca,case=False,regex=False)]
    tabela['representante']=tabela['cod_rep'].map(lambda x: f"{int(x)} - {reps.get(x,'')}" if pd.notna(x) else '')
    tabela['supervisor']=tabela['cod_sup'].map(lambda x: f"{int(x)} - {sups.get(x,'')}" if pd.notna(x) else '')
    cols={'codigo_grupo':'Grupo Cliente (chave)' ,'nome':'Grupo cliente','status':'Situação','ultima_compra':'Última compra','ultima_colecao':'Última coleção comprada','colecoes_sem_compra':'Coleções sem compra','bloqueio':'Bloqueio financeiro','bloqueadas':'Empresas bloqueadas','qtd_empresas':'Empresas no grupo','situacao_limite':'Situação limite','limite_total':'Limite informado (R$)','faturamento_historico':'Faturamento histórico (R$)','representante':'Representante','supervisor':'Supervisor'}
    tabela=tabela[list(cols)].rename(columns=cols).sort_values(['Coleções sem compra','Faturamento histórico (R$)'],ascending=[False,False])
    st.dataframe(tabela,use_container_width=True,hide_index=True)
    buffer=io.BytesIO()
    with pd.ExcelWriter(buffer,engine='openpyxl') as writer:
        tabela.to_excel(writer,index=False,sheet_name='Grupos')
    st.download_button('📥 Exportar grupos e situação financeira',buffer.getvalue(),file_name='churn_por_colecao.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    st.caption('Financeiro por grupo: todos os códigos de cliente vinculados. Confira se o campo bloqueado representa o status financeiro vigente e se limite_disponivel é de fato disponível ou limite cadastrado.')
